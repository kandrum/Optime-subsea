
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'naveen2628',
  applicationName: 'lambdasubsea3',
  appUid: 'q1jqVg2M4Xn4gpV9bS',
  orgUid: '6dbfebfb-1e3e-4b91-8dab-06ff8e10d9a0',
  deploymentUid: '6d91d065-7d14-4512-a391-4eac07dc9bcd',
  serviceName: 'serverlesslambda3',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.2.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverlesslambda3-dev-api', timeout: 6 };

try {
  const userHandler = require('./index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}