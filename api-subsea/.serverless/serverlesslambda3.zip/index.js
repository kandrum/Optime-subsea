const serverless = require("serverless-http");
const express = require("express");
const cors = require("cors");
const app = express();
require("dotenv").config();
const { checkUser } = require("./controlers/loginControler.js");
const { registerUser } = require("./controlers/registerControler.js");
const {
  addCompany,
  getAllCompanies,
  deleteCompany,
} = require("./controlers/addCompaniService");
const {
  addProject,
  fetchAllProjects,
  deleteProject,
} = require("./controlers/addProjectService.js");

const multer = require("multer");
const AdmZip = require("adm-zip");
const fs = require("fs");
const path = require("path");
const csv = require("csv-parser");
const PORT = 1226;

// CORS options to allow all origins and all HTTP methods
const corsOptions = {
  origin: "*", // Allow all origins
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"], // Allow all HTTP methods
  allowedHeaders: ["Content-Type", "Authorization"], // You can adjust the headers as needed
  credentials: true, // This allows cookies to be sent alongside requests, if needed
  optionsSuccessStatus: 200, // Some legacy browsers (IE11, various SmartTVs) choke on 204
};

// Use CORS middleware with the specified options
app.use(cors(corsOptions));

// Middleware to parse JSON bodies
app.use(express.json());

// Define routes
app.get("/", (req, res) => {
  res.send("Welcome to the API!");
});

app.get("/api/data", (req, res) => {
  res.json({ message: "Here is some data" });
});

app.post("/logincheck", (req, res) => {
  const userData = req.body;

  checkUser(userData)
    .then((result) => {
      if (result && result.checkstatus) {
        // User found, send a success response
        res.status(200).json({ message: "Login successful", result: result });
      } else {
        // No user found, send a not found response
        res
          .status(404)
          .json({ message: "User not found or incorrect password" });
      }
    })
    .catch((err) => {
      // Error handling, send a server error response
      console.error("Error during login check:", err);
      res.status(500).json({ message: "An error occurred during login check" });
    });
});
//creating a new router to recive data from frontend
app.post("/register", registerUser);

/* ---------------------------- POST endpoint to add a company --------------------------- */
app.post("/addcompany", (req, res) => {
  const { companyname, userid } = req.body;

  // Call the addCompany function with the company data
  addCompany({ companyname, userid })
    .then((result) => {
      // Send a success response with the result
      res.status(201).json(result);
    })
    .catch((error) => {
      // Send an error response
      res.status(500).json({ message: "Error adding company", error });
    });
});

/* ----------------------------------------  Endpoint to add a project --------------------- */
app.post("/addprojects", async (req, res) => {
  try {
    // Extract project data from request body
    const projectData = req.body;

    // Call the addProject function and await its response
    const result = await addProject(projectData);

    // Send success response
    res.status(201).json(result);
  } catch (err) {
    // Handle errors
    console.error("Error in /projects endpoint:", err.message);
    res.status(500).json({ message: "Failed to add project" });
  }
});

/* ---------------------------------------- get all companies ------------------------------- */
app.get("/getcompanies", async (req, res) => {
  try {
    const companies = await getAllCompanies();
    // Directly return the fetched companies data, which includes both companyid and companyname
    res.json(companies);
  } catch (err) {
    console.error("Error fetching companies:", err.message);
    res.status(500).json({ message: "Failed to fetch companies" });
  }
});

/* ---------------------------------------- get the projects ------------------------------- */

app.get("/getallprojects", async (req, res) => {
  try {
    const projects = await fetchAllProjects();
    res.status(200).json({
      message: "Projects fetched successfully",
      data: projects,
    });
  } catch (err) {
    console.error("Failed to fetch projects:", err);
    res.status(500).json({
      message: "Failed to fetch projects",
      error: err.message,
    });
  }
});

/* ---------------------------------------- delete company ------------------------------- */
app.delete("/deletecompany", async (req, res) => {
  const { companyid } = req.body; // Extract the company ID from the request body

  if (!companyid) {
    return res.status(400).json({ message: "Company ID must be provided" });
  }

  try {
    const result = await deleteCompany(companyid);
    if (result.message === "No company found with the provided ID") {
      res.status(404).json(result); // If no company is found, send a 404 response
    } else {
      res.status(200).json(result); // Send a success response
    }
  } catch (error) {
    console.error("Failed to delete company:", error);
    res.status(500).json({
      message: "Failed to delete the company due to an internal error.",
    });
  }
});
/* ---------------------------------------- delete project ------------------------------- */
app.delete("/deleteProject", async (req, res) => {
  try {
    // Assuming the projectId is sent in the request body or as a query parameter
    const projectId = req.body.projectId || req.query.projectId;

    if (!projectId) {
      return res.status(400).send({ message: "Project ID is required" });
    }

    const result = await deleteProject(projectId);

    if (result.message === "No project found with the specified ID") {
      return res.status(404).send(result);
    } else {
      return res.status(200).send(result);
    }
  } catch (err) {
    console.error("Error in /deleteProject route:", err);
    return res
      .status(500)
      .send({ message: "Error deleting project", error: err.message });
  }
});

/* ---------------------------------------- file upload ------------------------------- */
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    return cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    return cb(null, `${file.originalname}`);
  },
});
const upload = multer({ storage: storage });

// Corrected Multer middleware usage for file upload
app.post("/upload", upload.single("file"), (req, res) => {
  if (req.file) {
    res.status(200).json({
      message: "File uploaded successfully",
      filename: req.file.filename,
    });
  } else {
    res.status(400).json({ message: "No file uploaded" });
  }
});

app.get("/getkeys", (req, res) => {
  // Adjust the path to where your files are being stored
  const filePath = path.join(__dirname, "uploads", "keys.csv");

  let records = [];
  fs.createReadStream(filePath)
    .pipe(csv())
    .on("data", (row) => {
      if (records.length < 5) {
        records.push(row);
      }
    })
    .on("end", () => {
      res.status(200).json({
        message: "First 5 records fetched successfully",
        data: records,
      });
    })
    .on("error", (err) => {
      console.error("Error reading CSV file:", err);
      res.status(500).json({ message: "Failed to read CSV file" });
    });
});

/* ---------------------------------------- Start the server ------------------------------- */
/* app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
}); */

module.exports.handler = serverless(app);
